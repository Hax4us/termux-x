#
# Copyright (c) 2006-2018 Wade Alcorn - wade@bindshell.net
# Browser Exploitation Framework (BeEF) - http://beefproject.com
# See the file 'doc/COPYING' for copying permission
#
require 'test/unit'

class TC_CheckEnvironment < Test::Unit::TestCase

  def test_check_env
    # Add environment checks here

  end

end
